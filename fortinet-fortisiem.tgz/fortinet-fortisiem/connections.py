"""
Copyright start
Copyright (C) 2008 - 2026 FortinetInc.
All rights reserved.
FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
Copyright end
"""

import requests, base64, json
from .utils import *
from .forticloud_auth import generate_or_validate_token
from .constants import MAX_RETRIES, WAIT_TIME


class FortiSIEM:
    def __init__(self, config):
        self.base_url = config.get("server").strip("/") + "/phoenix"
        if not self.base_url.startswith("https://") and not self.base_url.startswith(
            "http://"
        ):
            self.base_url = "https://{0}".format(self.base_url)
        self.organization = config.get("organization")
        self.user = config.get("username")
        self.username = (
            self.organization + "/" + self.user if self.organization else self.user
        )
        self.password = str(config.get("password"))
        self.verify_ssl = config.get("verify_ssl", False)
        self.fsm_type = config.get("fsm_type", "FortiSIEM")
        self.cookies_dict = {}
        self.config = config

        self.error_msg = {
            400: "The parameters are invalid.",
            401: "Invalid credentials were provided Or Request Not authorized",
            403: "Access Denied",
            404: "The requested resource was not found",
            422: "Parameters are missing in query/request body.",
            423: "The parameters are invalid in path/query/request body.",
            500: "Internal Server Error",
            503: "Service Unavailable",
            "time_out": "The request timed out while trying to connect to the remote server",
            "ssl_error": "SSL certificate validation failed",
        }

    def get_headers(self, headers, resource_flag):
        if headers is None:
            if resource_flag:
                headers = {
                    "Accept": "application/json, text/plain, */*",
                    "Content-Type": "application/json;charset=UTF-8",
                    "Cookie": f"JSESSIONID={self.cookies_dict.get('JSESSIONID')}; s={self.cookies_dict.get('s')}",
                }
            else:
                headers = self.generate_headers()
        if headers:
            headers.update({"__no_session__": "true"})
        return headers

    def make_json_rest_call(
        self,
        endpoint,
        params=None,
        headers=None,
        json_data=None,
        data=None,
        cookies=None,
        method="GET",
        files=None,
        login_flag=False,
        resource_flag=False,
    ):
        # Instead of having a rest call with mixed data types (xml vs json, use this one for all json apis
        url = "{0}{1}".format(self.base_url, endpoint)
        try:
            if not headers:
                headers = self.get_headers(headers, resource_flag)
            logger.debug(f"Request Started")
            logger.debug(f"Request method {method}")
            logger.debug(f"Request url {url}")
            logger.debug(f"Request params {params}")
            logger.debug(f"Request data {data}")
            logger.debug(f"Request headers {headers}")
            response = requests.request(
                method,
                url,
                data=data,
                headers=headers,
                verify=self.verify_ssl,
                params=params,
                files=files,
            )

            logger.debug(f"Response Code {response.status_code}")
            logger.debug(f"Response Content {response.text}")

            if response.ok:
                logger.info(
                    "FortiSIEM successfully retrieved page: {0}".format(response.url)
                )
                try:
                    resp = response.json()
                except Exception:
                    resp = response.content.decode("utf-8")
                return response.status_code, resp
            elif response.status_code in [400, 404, 429, 503]:
                # 404 may mean FSM has not populated paginated cache yet
                # 503 means server is not ready for next page
                # Both indicate we should wait for some time before trying next page
                logger.error(
                    "Status Code: {0}, Query URL: {1} Response Data: {2}".format(
                        response.status_code, response.url, response.text
                    )
                )
                logger.error(
                    "FortiSIEM may sometimes return a 404 in older versions, in place of a 429 or 503, indicating that more time is needed for the server to be ready to serve more pages. Connector will retry the page after a short wait"
                )
                return response.status_code, response.text
            else:
                logger.error("{0}".format(response.content))
                raise ConnectorError(
                    "status code: {0}, error: {1}".format(
                        response.status_code, response.text
                    )
                )
        except requests.exceptions.SSLError as e:
            logger.exception("{0}".format(e))
            raise ConnectorError("{0}".format(self.error_msg["ssl_error"]))
        except requests.exceptions.ConnectionError as e:
            logger.exception("{0}".format(e))
        except Exception as e:
            logger.exception("{0}".format(e))
            raise ConnectorError("{0}".format(e))

    def make_rest_call(
        self,
        endpoint,
        params=None,
        headers=None,
        json_data=None,
        data=None,
        cookies=None,
        method="GET",
        files=None,
        login_flag=False,
        resource_flag=False,
    ):

        url = "{0}{1}".format(self.base_url, endpoint)
        try:
            if not headers:
                headers = self.get_headers(headers, resource_flag)
            logger.debug(f"Request Started")
            logger.debug(f"Request method {method}")
            logger.debug(f"Request url {url}")
            logger.debug(f"Request params {params}")
            logger.debug(f"Request data {data}")
            logger.debug(f"Request headers {headers}")
            response = requests.request(
                method,
                url,
                data=data.encode("utf-8") if isinstance(data, str) else data,
                headers=headers,
                verify=self.verify_ssl,
                params=params,
                files=files,
            )

            response_content = response.content.decode("utf-8")
            logger.debug(f"Response Code {response.status_code}")
            logger.debug(f"Response Content {response_content}")
            if 'error code="255"' in response_content:
                # if invalid input: response comes out to be 200, with error code 255
                json_resp = xmltodict.parse(response_content)
                # error_msg can come at any of the 2 locations, so checking here with or condition
                error_msg = json_resp.get("response", {}).get("error", {}).get(
                    "description"
                ) or json_resp.get("response", {}).get("result", {}).get(
                    "error", {}
                ).get(
                    "description"
                )
                logger.error(error_msg)
                raise ConnectorError("Error : {0}".format(error_msg))
            elif response.ok:
                if login_flag:
                    self.cookies_dict = response.cookies.get_dict()
                    return response_content, response.cookies
                elif response.headers.get(
                    "Content-Type"
                ) and "json" in response.headers.get("Content-Type"):
                    try:
                        resp = response.json()
                    except Exception:
                        resp = response_content
                    return resp
                elif response.text == "":
                    return response
                return response_content
            elif response.status_code == 400 and "json" in response.headers.get(
                "Content-Type"
            ):
                logger.error("{0}".format(response.text))
                raise ConnectorError(response.text)
            elif response.status_code in [404, 503]:
                # 404 may mean FSM has not populated paginated cache yet
                # 503 means server is not ready for next page
                # Both indicate we should wait for some time before trying next page
                logger.error("{0}".format(response.text))
                raise ConnectorError(response.text)
            elif response.status_code == 500:
                logger.error("{0}".format(response.content))
                raise ConnectorError(
                    "{0}".format(self.error_msg.get(response.status_code))
                )
            elif self.error_msg.get(response.status_code, None):
                logger.error("{0}".format(response.content))
                raise ConnectorError(
                    "status code: {0}, error: {1}".format(
                        response.status_code, self.error_msg[response.status_code]
                    )
                )
            raise ConnectorError(
                "status code: {0}, error: {1}".format(
                    response.status_code, response.content
                )
            )
        except requests.exceptions.SSLError as e:
            logger.exception("{0}".format(e))
            raise ConnectorError("{0}".format(self.error_msg["ssl_error"]))
        except requests.exceptions.ConnectionError as e:
            logger.exception("{0}".format(e))
            raise ConnectorError("{0}".format(self.error_msg["time_out"]))
        except Exception as e:
            logger.exception("{0}".format(e))
            raise ConnectorError("{0}".format(e))

    def make_rest_call_with_retries(self, endpoint, headers):
        attempt = 0
        while attempt < MAX_RETRIES:
            status_code, json_resp = self.make_json_rest_call(endpoint, headers=headers)
            if status_code in [200, 201, 202]:
                return json_resp
            elif status_code == 429:
                attempt += 1
                logger.info(
                    f"Rate limited {status_code}, retrying {attempt}/{MAX_RETRIES}..."
                )
                time.sleep(WAIT_TIME)
                if attempt == MAX_RETRIES:
                    logger.error("Max retry attempts reached. Please try again later.")
                    raise ConnectorError(f"Rate limit error: {json_resp}")
            else:
                raise ConnectorError(f"Error: {status_code} - {json_resp}")

    def generate_headers(self):
        try:
            if self.fsm_type == "FortiSIEM":
                auth = base64.b64encode((self.username + ":" + self.password).encode())
                return {"Authorization": "Basic {0}".format(auth.decode())}
            else:
                token = generate_or_validate_token(
                    self.config, self.config.get("connector_info", "")
                )
                endpoint = "/rest/soc/oauth/token"
                headers = {
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/x-www-form-urlencoded",
                }
                payload = "grant_type=soc_user"
                response = self.make_rest_call(
                    endpoint, method="POST", data=payload, headers=headers
                )

                # Based on the API response, we need to update the handling below.
                return {
                    "Authorization": "Bearer {0}".format(response.get("access_token"))
                }
        except Exception as err:
            logger.exception(err)
            raise ConnectorError(err)

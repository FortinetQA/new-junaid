"""
Copyright start
Copyright (C) 2008 - 2026 FortinetInc.
All rights reserved.
FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
Copyright end
"""

from connectors.core.connector import Connector, get_logger
from .operations import operations, _check_health
from django.conf import settings

logger = get_logger("fortinet-fortisiem")


class FortiSIEMConnector(Connector):
    def execute(self, config, operation, params, **kwargs):
        config["connector_info"] = {
            "connector_name": self._info_json.get("name"),
            "connector_version": self._info_json.get("version"),
        }
        action = operations.get(operation)
        if config.get("fsm_type") == "FortiSOC":
            config["server"] = settings.EMBEDDED_FORTISIEM_URL
        logger.info("Action name {0}".format(action))
        return action(config, params)

    def check_health(self, config):
        config["connector_info"] = {
            "connector_name": self._info_json.get("name"),
            "connector_version": self._info_json.get("version"),
        }
        if config.get("fsm_type") == "FortiSOC":
            config["server"] = settings.EMBEDDED_FORTISIEM_URL
        _check_health(config)

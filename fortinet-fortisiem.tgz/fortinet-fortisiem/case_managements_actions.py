"""
Copyright start
Copyright (C) 2008 - 2026 FortinetInc.
All rights reserved.
FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
Copyright end
"""
from os.path import join, basename, exists

from connectors.cyops_utilities.builtins import download_file_from_cyops
from integrations.crudhub import make_request

from .connections import *


def get_epoch_time(date_str, milli_seconds=False):
    try:
        pattern = '%Y-%m-%dT%H:%M:%S.%fZ'
        dt_obj = datetime.strptime(date_str, pattern)
        epoch_timestamp = int(dt_obj.timestamp())
        if milli_seconds:
            return epoch_timestamp * 1000
        return epoch_timestamp
    except Exception as e:
        logger.error(e)
        return date_str


def get_create_update_case_payload(params):
    incident_ids = params.get('incidentIds')
    if incident_ids and isinstance(incident_ids, str):
        params['incidentIds'] = incident_ids.split(',')
    elif incident_ids and isinstance(incident_ids, int):
        params['incidentIds'] = [incident_ids]
    due_date = params.get('dueDate')
    if due_date:
        params['dueDate'] = get_epoch_time(due_date, milli_seconds=True)
    payload = {k: v for k, v in params.items() if v not in (None, '', {}, [])}
    return payload


def create_case(config, params):
    try:
        fortisiem_obj = FortiSIEM(config)
        endpoint = '/rest/pub/case'
        headers = fortisiem_obj.generate_headers()
        headers.update({'Content-Type': 'application/json'})
        payload = get_create_update_case_payload(params)
        return fortisiem_obj.make_rest_call(endpoint, headers=headers, data=json.dumps(payload), method='POST')
    except Exception as err:
        logger.exception(err)
        raise ConnectorError(err)


def update_cases(config, params):
    try:
        fortisiem_obj = FortiSIEM(config)
        case_id = params.pop('caseId', '')
        endpoint = f'/rest/pub/case/{case_id}'
        headers = fortisiem_obj.generate_headers()
        headers.update({'Content-Type': 'application/json'})
        payload = get_create_update_case_payload(params)
        return fortisiem_obj.make_rest_call(endpoint, headers=headers, data=json.dumps(payload), method='PUT')
    except Exception as err:
        logger.exception(err)
        raise ConnectorError(err)


def get_case_analysts(config, params):
    try:
        fortisiem_obj = FortiSIEM(config)
        endpoint = f'/rest/pub/case/analysts'
        headers = fortisiem_obj.generate_headers()
        query_params = get_create_update_case_payload(params)
        to_date = params.get('timeTo')
        if to_date:
            query_params['timeTo'] = get_epoch_time(to_date)
        form_date = params.get('timeFrom')
        if form_date:
            query_params['timeFrom'] = get_epoch_time(form_date)
        return fortisiem_obj.make_rest_call(endpoint, headers=headers, params=query_params, method='GET')
    except Exception as err:
        logger.exception(err)
        raise ConnectorError(err)


def _get_file_content_using_iri(iri, iri_type):
    try:
        if iri_type == 'attachment':
            attachment_data = make_request(iri, 'GET')
            file_iri = attachment_data['file']['@id']
        else:
            file_iri = iri
        file_download_response = download_file_from_cyops(file_iri)
        file_name = file_download_response.get('filename')
        file_path = join('/tmp', file_download_response.get('cyops_file_path'))

        return get_file_content_from_file_path(file_path, file_name)

    except Exception as err:
        logger.exception(f"Error occurred: {err}")
        raise ConnectorError(f"Error while processing the file: {err}")


def get_file_content_from_file_iri(iri):
    iri_type = 'file' if iri.startswith('/api/3/files') else 'attachment'
    if not iri.startswith('/api/3/'):
        iri = '/api/3/attachments/' + iri
    return _get_file_content_using_iri(iri, iri_type)


def get_file_content_from_file_path(file_path, file_name=''):
    file_path = file_path if file_path.startswith('/tmp') else join('/tmp', file_path)
    file_name = file_name if file_name else basename(file_path)
    if not exists(file_path):
        raise ConnectorError(f"File at {file_path} does not exist.")
    with open(file_path, 'rb') as fp:
        file_data = fp.read() or b''
    return file_name, file_data


def upload_attachment_for_case(config, params):
    try:
        fortisiem_obj = FortiSIEM(config)
        case_id = params.get('caseID')
        endpoint = f'/rest/pub/case/{case_id}/attachment'
        headers = fortisiem_obj.generate_headers()
        if params.get('upload_option') == 'IRI':
            file_name, file_data = get_file_content_from_file_iri(params.get('file_iri'))
        else:
            file_name, file_data = get_file_content_from_file_path(params.get('file_path'))
        if not file_data:
            raise ConnectorError("File data is missing or empty")
        files = [('file', (file_name, file_data))]
        resp = fortisiem_obj.make_rest_call(endpoint, headers=headers, method='POST', files=files)
        return {'status': 'success', 'message': f'file successfully uploaded as an attachment in the case: {case_id}'
                } if isinstance(resp, requests.Response) and not resp.text else resp
    except Exception as err:
        logger.error(f"Error uploading attachment: {err}")
        raise ConnectorError(f"Error uploading attachment: {err}")



def get_list_cases(config, params):
    fortisiem_obj = FortiSIEM(config)
    run_for_organization = params.get('runForOrganization','').strip()
    if run_for_organization and isinstance(run_for_organization, str):
        params['runForOrganization'] = [run_for_organization]
    order_by = params.get('orderBy', '').strip()
    if order_by and isinstance(order_by, str):
        params['orderBy'] = [order_by]
    query_params = {k: v for k, v in {'size': params.get('size'), 'start': params.get('start')}.items() if
                    v not in (None, '', {}, [])}
    endpoint = f'/rest/query/cmdb'
    headers = fortisiem_obj.generate_headers()
    headers.update({'Content-Type': 'application/json'})
    payload = {k: v for k, v in params.items() if v not in (None, '', {}, [])}
    select_fields = payload.pop('selectFields','')
    if select_fields and isinstance(select_fields, str):
        select_fields = select_fields.split(",")
    if select_fields and isinstance(select_fields, list):
        select_fields = [field.strip() for field in select_fields]
    payload['selectFields'] = select_fields
    payload['target'] = 'CASE'
    resp= fortisiem_obj.make_rest_call(endpoint, headers=headers, method='POST', params=query_params,
                                        data=json.dumps(payload))
    resp = json.loads(resp) if not isinstance(resp, (dict, list)) else resp
    return process_response_data(resp)

def get_case_field_schema(config, params):
    fortisiem_obj = FortiSIEM(config)
    endpoint = f'/rest/query/cmdb/schema'
    query_params = {'target': 'CASE'}
    headers = fortisiem_obj.generate_headers()
    resp = fortisiem_obj.make_rest_call(endpoint, headers=headers, method='GET', params=query_params)
    return json.loads(resp) if not isinstance(resp, (dict, list)) else resp


def generic_rest_api_call(config, params):
    fortisiem_obj = FortiSIEM(config)
    endpoint = params.get('endpoint', '')
    query_params = params.get('query_params', {})
    method = params.get('method', '')
    payload = params.get('payload')
    headers = fortisiem_obj.generate_headers()
    if params.get('content_type', None):
        headers['Content-Type'] = params.get('content_type')
    data = json.dumps(payload) if payload else None
    if not endpoint.startswith('/'):
        endpoint = f'/{endpoint}'
    resp = fortisiem_obj.make_rest_call(endpoint, headers=headers, params=query_params, method=method, data=data)
    if resp:
        try:
            return xmltodict.parse(resp)
        except Exception:
            try:
                return json.loads(resp)
            except Exception:
                return resp
    return resp

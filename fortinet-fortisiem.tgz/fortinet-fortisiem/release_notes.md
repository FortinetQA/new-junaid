#### The following enhancements have been made to the Fortinet FortiSIEM connector in version 6.0.0:

- A new configuration parameter, FortiSIEM Type, has been introduced with the following options: 
  - FortiSIEM - For on-premises deployments. 
  - FortiSOC - For FortiSOC deployments. 
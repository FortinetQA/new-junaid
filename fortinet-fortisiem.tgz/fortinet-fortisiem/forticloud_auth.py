""" Copyright start
  Copyright (C) 2008 - 2026 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end """

import requests, json
from time import time, ctime
from datetime import datetime
from .forticloud_token import *
from connectors.core.utils import update_connnector_config
from connectors.core.connector import ConnectorError, get_logger


def convert_ts_epoch(ts):
    datetime_object = datetime.strptime(ctime(ts), "%a %b %d %H:%M:%S %Y")
    return datetime_object.timestamp()

def generate_token(config, is_refresh_token=False):
    try:
        if config.get("is_fsoc"):
            # Works only for FortiSOC Environment.
            token_resp = acquire_cloud_token(is_refresh_token, config)
            token_resp['expiresOn'] = token_resp['expires_in'] if token_resp.get("expires_in") else None
        else:
            # Works for Forti Cloud and on prem environment.
            token_resp = acquire_token(is_refresh_token, config)
            ts_now = time()
            token_resp['expiresOn'] = (ts_now + token_resp['expires_in']) if token_resp.get("expires_in") else None
        token_resp['accessToken'] = token_resp.get("access_token")
        token_resp['refreshToken'] = token_resp.get("refresh_token")
        token_resp.pop("access_token")
        return token_resp
    except Exception as err:
        logger.error("{0}".format(err))
        raise ConnectorError("{0}".format(err))

def validate_token(connector_config, connector_info):
    try:
        ts_now = time()
        if not connector_config.get('accessToken'):
            logger.error('Error occurred while connecting server: Unauthorized')
            raise ConnectorError('Error occurred while connecting server: Unauthorized')
        expires = connector_config['expiresOn']
        expires_ts = convert_ts_epoch(expires)
        # Why -5.
        # Consider that only a second is left for access token to expire, then till time request goes to FortiAnalyzer
        # Followed by Cloud the token will get expire, so taken 5 as margin time
        if ts_now > (float(expires_ts) - 5):
            logger.warning("Previous Token expired at {0}".format(expires))
            token_resp = generate_token(connector_config, is_refresh_token=True)
            connector_config['accessToken'] = token_resp.get('accessToken')
            connector_config['expiresOn'] = token_resp.get('expiresOn')
            if token_resp.get('refreshToken'):
                connector_config['refreshToken'] = token_resp.get('refreshToken')
            update_connnector_config(connector_info.get('connector_name'), connector_info.get('connector_version'),
                                     connector_config,
                                     connector_config.get('config_id'))

            return connector_config.get('accessToken')
        else:
            logger.info("Token is valid till {0}".format(expires))
            return connector_config.get('accessToken')
    except Exception as err:
        logger.error("{0}".format(str(err)))
        raise ConnectorError("{0}".format(str(err)))


def acquire_token(is_refresh_token, config, ):
    try:
        headers = {
            'Content-Type': 'application/json'
        }
        if not is_refresh_token:
            data = {
                "username": config.get('username'),
                "password": config.get('password'),
                "client_id": config.get('client_id'),
                "grant_type": "password"
            }
        else:
            data = {
                "grant_type": "refresh_token",
                "refresh_token": config.get('refresh_token'),
                "client_id": config.get('client_id')
            }
        logger.debug("Payload: {0}".format(data))
        endpoint = 'https://customerapiauth.fortinet.com/api/v1/oauth/token/'
        logger.debug("Endpoint: {0}".format(endpoint))
        response = requests.post(endpoint, data=json.dumps(data), headers=headers, verify=config.get('verify_ssl'), timeout=60)
        logger.debug("Response: {0}".format(response))
        if response.status_code in [200, 204, 201]:
            return response.json()
        else:
            if response.text != "":
                err_resp = response.json()
                if err_resp and 'error' in err_resp:
                    failure_msg = err_resp.get('error_description')
                    error_msg = 'Response {0}: {1} \n Error Message: {2}'.format(response.status_code,
                                                                                 response.reason,
                                                                                 failure_msg if failure_msg else response.text)
                else:
                    error_msg = response.text
            else:
                error_msg = '{0}:{1}'.format(response.status_code, response.reason)
            raise ConnectorError(error_msg)

    except Exception as err:
        logger.error("{0}".format(str(err)))
        raise ConnectorError(str(err))


def generate_or_validate_token(config, connector_info):
    try:
        if not 'accessToken' in config:
            token_resp = generate_token(config)
            config['accessToken'] = token_resp.get('accessToken')
            config['expiresOn'] = token_resp.get('expiresOn')
            config['refreshToken'] = token_resp.get('refreshToken')
            update_connnector_config(connector_info['connector_name'], connector_info['connector_version'], config,
                                     config['config_id'])
            return config.get('accessToken')
        else:
            return validate_token(config, connector_info)
    except Exception as err:
        raise ConnectorError(str(err))

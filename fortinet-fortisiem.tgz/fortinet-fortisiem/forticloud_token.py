""" Copyright start
  Copyright (C) 2008 - 2026 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end """
from django.conf import settings
from integrations.crudhub import make_request
from connectors.core.connector import get_logger, ConnectorError
from .constants import CLOUD_TOKEN_URL, TOKEN_DESCRIPTION, CLOUD_REFRESH_TOKEN_URL

logger = get_logger('fortinet-fortisiem')


def _aquire_new_token_and_refresh_token():
    url = f"{settings.CRUD_HUB_URL}{CLOUD_TOKEN_URL}"
    try:
        response = make_request(
            url=url,
            method='POST',
            body={"description": TOKEN_DESCRIPTION}
        )
        logger.error(f"Token response: {response}")
        return response
    except Exception as err:
        logger.error(f"Failed to acquire token: {err}")
        raise ConnectorError(f"Token acquisition failed: {err}")


def acquire_cloud_token(is_refresh_token, config):
    if not is_refresh_token:
        logger.debug(f"Requesting new cloud and refresh token using secret")
        return _aquire_new_token_and_refresh_token()
    else:
        logger.debug(f"Requesting new cloud and refresh token using refresh token")
        url = f"{settings.CRUD_HUB_URL}{CLOUD_REFRESH_TOKEN_URL}"
        refresh_token = config.get('refreshToken')
        if not refresh_token:
            logger.error("Refresh token not found in config")
            raise ConnectorError("Refresh token required for token refresh")

        try:
            response = make_request(
                url=url,
                method='PUT',
                body={'refresh_token': refresh_token}
            )
            return response
        except Exception as err:
            # This is a scenario where your refresh token too is expired.
            # In this scenario always aquire the new token and refresh token and if it fails
            # then raise the error.
            return _aquire_new_token_and_refresh_token()